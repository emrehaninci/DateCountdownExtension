# DateCountdownExtension

### [Download the Extension from Chrome Web Store](https://chrome.google.com/webstore/detail/date-countdown/pkihdfohnndkhmnfjooipkpemdikgkhb)
* A simple Chrome Extension to track how many days left to the any date you want!

## SCREENSHOTS

![image](https://user-images.githubusercontent.com/47064744/193264822-a693993b-4567-4769-bd3a-31aa107862f0.png)
![add-item](https://user-images.githubusercontent.com/47064744/193264843-576ecf0f-5232-4fd1-9204-cd001c57b963.gif)
